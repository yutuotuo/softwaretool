## 蓝灯(Lantern)最新版本下载

**🔴[蓝灯最新版本下载地址请点这里](https://github.com/getlantern/forum/issues/833)🔴**

最新版本是4.4.x

[Windows 版本(要求XP SP3以上)](https://raw.githubusercontent.com/getlantern/lantern-binaries/master/lantern-installer.exe)      [备用地址](https://s3.amazonaws.com/lantern/lantern-installer.exe)  

[安卓版(要求4.1以上)](https://raw.githubusercontent.com/getlantern/lantern-binaries/master/lantern-installer.apk)               [备用地址](https://s3.amazonaws.com/lantern/lantern-installer.apk)  [Google Play下载](https://play.google.com/store/apps/details?id=org.getlantern.lantern) 

[其他系统下载](https://github.com/getlantern/forum/issues/833)

请大家收藏本页面，方便日后下载新版。

## 蓝灯官方论坛

[论坛帖子页面请点这里进入](https://github.com/getlantern/forum/issues?q=is%3Aissue+is%3Aopen+sort%3Aupdated-desc)，或者点击左上方的Issues进入。

你可以在右上角“sign up” 注册账号。 通过邮件验证后，请点击 https://github.com/getlantern/forum 回到论坛。

在论坛内，可用右上角使用“New issue” 发新帖，或者在帖内使用“Comment”回复。

### 版规
🔴**使用遇到问题，请阅读[蓝灯无法使用的解决办法](https://github.com/getlantern/forum/issues/1902)。** 
提问前，请先阅读[蓝灯精华帖](https://github.com/getlantern/forum/issues?q=is%3Aopen+is%3Aissue+label%3A%E7%B2%BE%E5%8D%8E)。 🔴

本论坛可进行关于蓝灯(Lantern)翻墙软件的讨论。因为版面有限，请不要重复发帖，邀请码在本论坛请以签名形式发布或发到其他论坛。
禁止广告帖，包括非官方的讨论群。禁止刷版，人身攻击等恶劣行为。屡次违反版规会禁言甚至封号。

