请在发帖前先按照蓝灯无法使用的解决办法 https://github.com/getlantern/forum/issues/1902 自行解决。自行解决问题通常只需要几十分钟。管理员调查解决问题需要几天至几周。请立即访问https://github.com/getlantern/forum/issues/1902 瞬间解决98%的问题

为了能在最快的时间内解决大家使用蓝灯遇到的问题，请各位用户严格按照发帖格式提交问题。

## 发帖格式
遇到的问题：请详细描述遇到的问题。如果描述不仔细，将无法调查

蓝灯专业版账号Email:  请提供登陆蓝灯专业版的email，免费版不提供技术支持。

应用内报告问题的时间:  请根据 https://github.com/getlantern/forum/issues/1840 在应用内上报问题，请填写专业版的email。请在帖子里注明报告的时间。

截图: 请提供有关问题的截图。 请把图片拖拽到这里。


----
邀请码在本论坛请以签名形式发布或发到其他论坛。具体见 https://github.com/getlantern/forum/issues/3773




